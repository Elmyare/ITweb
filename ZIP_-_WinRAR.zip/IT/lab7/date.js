function clock() {
	var date12 = new Date();
	var hours12 = date12.getHours() - (date12.getHours() >= 12 ? 12 : 0);
	var period = date12.getHours() >= 12 ? 'PM' : 'AM';
	var minutes12 = date12.getMinutes();
	var seconds12 = date12.getSeconds();
	if (seconds12 < 10){
		seconds12 = "0" + seconds12;
	}
	var seconds1 = Math.floor(seconds12 / 10);
	var seconds2 = seconds12 % 10;
	var dy = parseInt(date12.getDate());
	var dy1 = Math.floor(dy / 10);
	var dy2 = dy % 10;
	var month = parseInt(date12.getMonth())+1;
	var mth1 = Math.floor(month / 10);
	var mth2 = month % 10;
	var year = date12.getFullYear();
	var yr4 = year % 10; //202"2"
	var yr3 = Math.floor((year / 10)) % 10; // 20"2"2
	var yr2 = Math.floor((Math.floor((year / 10)) / 10)) % 10; // 2"0"22
	var yr1 = Math.floor((year / 1000)); // "2"022
		if (minutes12 < 10) minutes12 = "0" + minutes12;
	var hours1 = Math.floor(parseInt(hours12) / 10);
	var hours2 = parseInt(hours12) % 10;
	var minutes1 = Math.floor(parseInt(minutes12) / 10);
	var minutes2 = parseInt(minutes12) % 10;
		for(var z = 0; z < 1; z++){
			if(hours1 == z)
			hours1 = "<img src = 'dg" + z + ".gif'>";
		}
		for(var x = 0; x < 10; x++){
			if(hours2 == x)
			hours2 = "<img src = 'dg" + x + ".gif'>";
		}

		for(var z = 0; z < 6; z++){
			if(minutes1 == z){
	 			minutes1 = "<img src = 'dg" + z + ".gif'>";
			}
		}
		for(var x = 0; x < 10; x++){
			if(minutes2 == x){
				minutes2 = "<img src = 'dg" + x + ".gif'>";
			}
		}
		for(var z = 0; z < 6; z++){
			if(seconds1 == z){
				seconds1 = "<img src = 'dg" + z + ".gif'>";
			}
		}
		for(var x = 0; x < 10; x++){
			if(seconds2 == x){
				seconds2 = "<img src = 'dg" + x + ".gif'>";
			}
		}

		if(period == 'AM'){
			period = "<img src = 'dgam.gif'>";
		}
		else{
			period = "<img src = 'dgpm.gif'>";
		}

		for(var z = 0; z < 4; z++){
			if(dy1 == z){
				dy1 = "<img src = 'dg" + z + ".gif'>";
			}
		}
		for(var x = 0; x < 10; x++){
			if(dy2 == x){
				dy2 = "<img src = 'dg" + x + ".gif'>";
			}
		}
		if (mth1 == 0) {
			mth1 = "<img src = 'dg0.gif'>";
		}
		if (mth1 == 1) {
			mth1 = "<img src = 'dg1.gif'>";
		}
		if (mth2 == 0) {
			mth2 = "<img src = 'dg0.gif'>";
		}
		if (mth2 == 1) {
			mth2 = "<img src = 'dg1.gif'>";
		}
		if (mth2 == 2) {
			mth2 = "<img src = 'dg2.gif'>";
		}

		for(var z = 0; z < 10; z++){
			if(yr1 == z){
				yr1 = "<img src = 'dg" + z + ".gif'>";
			}
		}

		for(var x = 0; x < 10; x++){
			if(yr2 == x){
				yr2 = "<img src = 'dg" + x + ".gif'>";
			}
		}		
		
		for(var c = 0; c < 10; c++){
			if(yr3 == c){
				yr3 = "<img src = 'dg" + c + ".gif'>";
			}
		}

		for(var v = 0; v < 10; v++){
			if(yr4 == v){
				yr4 = "<img src = 'dg" + v + ".gif'>";
			}
		}


	document.getElementById("clock12").innerHTML = hours1 + hours2 + "<img src = 'dgc.gif'>" + minutes1 + minutes2 + "<img src = 'dgc.gif'>" + seconds1 + seconds2 + period;
	setTimeout("clock()", 1000);
	document.getElementById("data12").innerHTML = dy1 + dy2 + "<img src = 'dgp.gif'>" + mth1 + mth2 + "<img src = 'dgp.gif'>" + yr1 + yr2 + yr3 + yr4;
	setTimeout("clock()", 1000);
}