var flag = 0;

function change() {
    if (flag == 0) {
    var temp = document.getElementById("l_img").src;
    document.getElementById("l_img").src = document.getElementById("r_img").src;
    document.getElementById("r_img").src = temp;
    flag = 1;
    } 
}

function changeback() {
    if (flag == 1) {
    var temp = document.getElementById("l_img").src;
    document.getElementById("l_img").src = document.getElementById("r_img").src;
    document.getElementById("r_img").src = temp;
    flag = 0
    }
}

