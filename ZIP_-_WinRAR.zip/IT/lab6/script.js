var s = ParseInt(document.getElementByName("t1").value);
var p = ParseInt(document.getElementById('t2').value);
function calculate() {
	t2.value = t1.value*t1.value; 
}
